package com.lera.CRUDwithAngular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CruDwithAngularApplication {

	public static void main(String[] args) {
		SpringApplication.run(CruDwithAngularApplication.class, args);
	}

}
